#include <iostream>
#include <string>
#include <fstream>

#include <rw/rw.hpp>
#include <rw/invkin.hpp>
#include <rw/math/Random.hpp>
#include <rw/loaders/WorkCellLoader.hpp>
#include <rwlibs/proximitystrategies/ProximityStrategyFactory.hpp>


USE_ROBWORK_NAMESPACE
using namespace robwork;


void writeFile(std::string fileName,
               const std::vector<float> &xPos,
               const std::vector<float> &yPos,
               std::vector<unsigned int> solutionsVector){
    std::ofstream myFile;
    myFile.open(fileName);

    std::cout << "Writing to file: " + fileName << std::endl;   // Write to text file


    for(unsigned int i = 0; i < solutionsVector.size(); i++){
        myFile << xPos[i] << " " << yPos[i] << " " <<solutionsVector[i] << std::endl;
    }

    myFile.close();
    std::cout << "Done writing to file: " + fileName << std::endl;
}

std::vector<rw::math::Q> getConfigurations(const std::string nameGoal,
                                           const std::string nameTcp,
                                           rw::models::SerialDevice::Ptr robot,
                                           rw::models::WorkCell::Ptr wc,
                                           rw::kinematics::State state){


    const std::string robotName = robot->getName();
    const std::string nameRobotBase = robotName + "." + "Base";     // Get, make and print name of frames
    const std::string nameRobotTcp = robotName + "." + "TCP";


    rw::kinematics::Frame* frameGoal = wc->findFrame(nameGoal);
    rw::kinematics::Frame* frameTcp = wc->findFrame(nameTcp);
    rw::kinematics::Frame* frameRobotBase = wc->findFrame(nameRobotBase);                                        // Find frames and check for existence
    rw::kinematics::Frame* frameRobotTcp = wc->findFrame(nameRobotTcp);
    if(frameGoal==NULL || frameTcp==NULL || frameRobotBase==NULL || frameRobotTcp==NULL){

        std::cout << " ALL FRAMES NOT FOUND:" << std::endl;
        std::cout << " Found \"" << nameGoal << "\": " << (frameGoal==NULL ? "NO!" : "YES!") << std::endl;
        std::cout << " Found \"" << nameTcp << "\": " << (frameTcp==NULL ? "NO!" : "YES!") << std::endl;
        std::cout << " Found \"" << nameRobotBase << "\": " << (frameRobotBase==NULL ? "NO!" : "YES!") << std::endl;
        std::cout << " Found \"" << nameRobotTcp << "\": " << (frameRobotTcp==NULL ? "NO!" : "YES!") << std::endl;
    }


    rw::math::Transform3D<> frameBaseTGoal = rw::kinematics::Kinematics::frameTframe(frameRobotBase, frameGoal, state);
    rw::math::Transform3D<> frameTcpTRobotTcp = rw::kinematics::Kinematics::frameTframe(frameTcp, frameRobotTcp, state);


    rw::math::Transform3D<> targetAt = frameBaseTGoal * frameTcpTRobotTcp;

    rw::invkin::ClosedFormIKSolverUR::Ptr closedFormSolver = rw::common::ownedPtr(new rw::invkin::ClosedFormIKSolverUR(robot, state));
    return closedFormSolver->solve(targetAt, state);
}

std::vector<rw::math::Q> getCollisionFreeSolutions(rw::models::WorkCell::Ptr wc, rw::models::SerialDevice::Ptr robotUR6, rw::kinematics::MovableFrame::Ptr object, rw::kinematics::State state) {


    rw::kinematics::MovableFrame *target = wc->findFrame<rw::kinematics::MovableFrame>("GraspTarget");


    rw::proximity::CollisionDetector::Ptr detector = rw::common::ownedPtr(new rw::proximity::CollisionDetector(wc, rwlibs::proximitystrategies::ProximityStrategyFactory::makeDefaultCollisionStrategy()));


    std::vector<rw::math::Q> collisionFreeSolutions;                                                        
    if (target == nullptr){
        RW_THROW("Error: could not find GraspTarget!");
        return collisionFreeSolutions;
    }

    // sample the solutions in a loop (360  deg around yawAngle) with resolution of 1 deg for every degree around the yaw axis
    for (double yaw = 0; yaw < 2*rw::math::Pi; yaw += rw::math::Deg2Rad*1) {

        // Rotate the axis so the grasp target is from the top
        rw::math::RPY<> rotTarget(0, yaw, 0);// Rotation

        // Get position from object frame to use for target frame
        rw::math::Vector3D<> posTarget = object->getTransform(state).P();

        // construct transformation matrix with target position and target rotation with the axis rotated so that the object is grasped from the top
        rw::math::Transform3D<> newTarget (posTarget,object->getTransform(state).R()*rotTarget.toRotation3D());

        target->moveTo(newTarget, state);                           // Use the function MoveTo to move the manipulator to new target



        std::vector<rw::math::Q> solutions = getConfigurations("GraspTarget", "GraspTCP", robotUR6, wc, state);

        // check all the configurations for collisions
        for (unsigned int i = 0; i < solutions.size(); i++) {

            // set the robot in that configuration and check if there is a collision
            robotUR6->setQ(solutions[i], state);

            // loop and check the solutions if there is a collision
            if (!detector->inCollision(state, NULL, true)) {
                std::cout << solutions[i] << std::endl;

                // save it
                collisionFreeSolutions.push_back(solutions[i]);
                break;
            }
        }
    }

    // Print the number of collision free solutions
    std:: cout << "Current position of the robot vs object to be grasped has: "
               << collisionFreeSolutions.size()
               << " collision-free inverse kinematics solutions!" << std::endl;


    TimedStatePath tStatePath;
    double time = 0;

    if (collisionFreeSolutions.size() > 0) {
        for (unsigned int i = 0; i < collisionFreeSolutions.size(); i++) {

            robotUR6->setQ(collisionFreeSolutions[i], state);

            tStatePath.push_back(TimedState(time, state));

            //Printing the solutions
            std:: cout << "Solution: "
                       << collisionFreeSolutions[i]
                       << std::endl;

            time +=0.01;

            //generate rwplay file
            std::string rwplayPath = "/home/student/Desktop/Robotics/WorkCell/rwplayTop";
            rw::loaders::PathLoader::storeTimedStatePath(*wc, tStatePath, rwplayPath + "/visu.rwplay");
        }
    }




    return collisionFreeSolutions;
}

std::vector<rw::math::Vector3D<double>> generateRandomBasePosition(int iterations){
    std::vector<rw::math::Vector3D<double>> randomBasePositions;

    for(int i = 0; i < iterations ; i++){
        double randomX = rw::math::Random::ran(-0.3, 0.0);   // x goes from -0.3 to 0.3
        double randomY = rw::math::Random::ran(-0.2, 0.1);   // y goes from 0.2 to -0.5

        
        if (randomY < -0.3 && randomX > 0.1){
            continue;
        }
        else{
           
            rw::math::Vector3D<double> position(randomX,randomY,0.0);
            randomBasePositions.push_back(position);
        }
    }
    return randomBasePositions;
}



int main(int argc, char** argv){



    std::string filePath;

    // load workcell
    static std::string workcellPath = "/home/student/Desktop/Robotics/WorkCell";
    static const std::string wcPathFile = workcellPath + "/Scene.wc.xml";
    rw::models::WorkCell::Ptr wc = rw::loaders::WorkCellLoader::Factory::load(wcPathFile);
    if(NULL==wc){
        RW_THROW("Could not load scene... check path!");
        return -1;
    }

    // loading UR6 robot
    const std::string deviceName = "UR-6-85-5-A";
    rw::models::SerialDevice::Ptr robotUR6 = wc->findDevice<rw::models::SerialDevice>(deviceName);
    if (NULL == robotUR6){
        RW_THROW("Could not find device " + deviceName + "... check model!");
        return -1;
    }

    // Find relevant frames

    // find robot base frame
    const std::string baseName = "URReference";
    rw::kinematics::MovableFrame::Ptr baseFrame = wc->findFrame<rw::kinematics::MovableFrame>(baseName);
    if (NULL == baseFrame){
        RW_THROW("Could not load" + baseName + "... check model");
        return -1;
    }

    // find tool frame
    const std::string toolFrameName = "GraspTCP";
    rw::kinematics::Frame::Ptr toolFrame = wc->findFrame<rw::kinematics::Frame>(toolFrameName);
    if(NULL == toolFrame){
        RW_THROW("Could not load" + toolFrameName + "... check model!");
        return -1;
    }

    // find cylinder frame
    const std::string cylinderName = "Cylinder";
    rw::kinematics::MovableFrame::Ptr cylinderFrame = wc->findFrame<rw::kinematics::MovableFrame>(cylinderName);
    if (NULL == cylinderFrame){
        RW_THROW("Could not load" + cylinderName + "... check model!");
        return -1;
    }

    // Create collision detector --which will be used by the getCollisionFreeSolutions Function
    rw::proximity::CollisionDetector::Ptr detector = rw::common::ownedPtr(new rw::proximity::CollisionDetector(wc, rwlibs::proximitystrategies::ProximityStrategyFactory::makeDefaultCollisionStrategy()));

    // Get the default state and default rotation
    rw::kinematics::State state = wc->getDefaultState();
    rw::math::Rotation3D<> baseRotation = baseFrame->getTransform(state).R();
    rw::math::Rotation3D<> cylinderRotation = cylinderFrame->getTransform(state).R();

    std::vector<rw::math::Vector3D<double>> randomBasePositions = generateRandomBasePosition(30);


    // Create vector with all the cylinder positions to test
    std::vector<rw::math::Vector3D<>> cylinderPosition = {

            // cylinder Positioned on the Right — Picking area
            // rw::math::Vector3D<>(-0.25, 0.474, 0.150),

            // cylinder Positioned on the Left — Picking area
             // rw::math::Vector3D<>(0.25, 0.473, 0.110),

            // cylinder Positioned in the Middle — Picking area
           // rw::math::Vector3D<>(0.0, 0.474, 0.150),

            // cylinder — Placing area
            rw::math::Vector3D<>(0.3, -0.5, 0.15),
    };

   
    std::vector<unsigned int> numberOfSols;
    std::vector<float> xPos, yPos;

    for (unsigned int i = 0; i < randomBasePositions.size(); i++ ){

        // Move robot base frame to new random base position
        rw::math::Transform3D<> baseTransform(randomBasePositions[i], baseRotation);
        baseFrame->moveTo(baseTransform, state);

        // Change cylinder positions
        unsigned int solutions = 0;


        for(unsigned int j = 0; j < cylinderPosition.size(); j++){
            // Move cylinder
            rw::math::Transform3D<> cylinderTransform(cylinderPosition[j],cylinderRotation);
            cylinderFrame->moveTo(cylinderTransform, state);

            // Get collision free solutions
            std::vector<rw::math::Q> collisionFreeSols = getCollisionFreeSolutions(wc, robotUR6, cylinderFrame, state);

            // Store number of solutions
            solutions += collisionFreeSols.size();

            // Save data
            xPos.push_back(randomBasePositions[i](0));
            yPos.push_back(randomBasePositions[i](1));
            numberOfSols.push_back(solutions);
        }
    }


    writeFile("side.txt",xPos, yPos, numberOfSols);//Chnage for the given type of reachibilty

    return 0;
}



