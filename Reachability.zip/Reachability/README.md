
This folder contains the code for performing the reachibilty grasping analysis in the scene of RobWorkStudio from top and side

## Task description

In order to execute the grasping section, you are asked to perform 2 specific task.
To do the grasping analysis choose the part of top and side in collisioselect.cpp and add to line (Line 88 to 101)
Test the performance with at least all different pick location of the object in the scene.
