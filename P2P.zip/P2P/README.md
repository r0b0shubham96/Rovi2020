
This folder contains the code for both Point to point linear and blend interpolation

## Task description

In order to execute the point to point code section, you are asked to perform task by keeping object at 3 different pick location
To do select linear.cpp and run cmake
Test the performance with at least all different pick location of the object in the scene.
