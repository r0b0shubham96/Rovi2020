
This folder contains the code for general workcell of robotics
## Task description

just run the robwork studio and open the scene.wc.xml
