#ifndef SAMPLEPLUGIN_HPP
#define SAMPLEPLUGIN_HPP

//MINE


#include <eigen3/Eigen/Eigen>
using namespace Eigen;

#include <covis/covis.h>
using namespace covis;


#include <boost/foreach.hpp>
#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/filters/convolution_3d.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/surface/mls.h>
#include <pcl/filters/passthrough.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/filters/crop_box.h>
#include <pcl/point_cloud.h>
#include <pcl/common/random.h>
#include <pcl/common/time.h>
#include <pcl/features/normal_3d.h>
#include <pcl/features/spin_image.h>
#include <pcl/registration/correspondence_rejection_sample_consensus.h>
#include <pcl/registration/transformation_estimation_svd.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/search/kdtree.h>

// RobWork includes
#include <rw/models/WorkCell.hpp>
#include <rw/kinematics/State.hpp>
#include <rwlibs/opengl/RenderImage.hpp>
#include <rwlibs/simulation/GLFrameGrabber.hpp>
#include <rwlibs/simulation/GLFrameGrabber25D.hpp>

#include <rw/rw.hpp>
#include <rwlibs/pathplanners/rrt/RRTPlanner.hpp>
#include <rwlibs/pathplanners/rrt/RRTQToQPlanner.hpp>
#include <rwlibs/proximitystrategies/ProximityStrategyFactory.hpp>
#include <rw/trajectory/LinearInterpolator.hpp>


// RobWorkStudio includes
#include <RobWorkStudioConfig.hpp> // For RWS_USE_QT5 definition
#include <rws/RobWorkStudioPlugin.hpp>

// OpenCV 3
#include <opencv2/opencv.hpp>
#include <opencv2/core/eigen.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/rgbd/linemod.hpp>
#include <eigen3/Eigen/Eigen>
#include <covis/covis.h>


// Qt
#include <QTimer>

#include "ui_SamplePlugin.h"

#include <rws/RobWorkStudio.hpp>

#include <QPushButton>

#include <rw/loaders/ImageLoader.hpp>
#include <rw/loaders/WorkCellFactory.hpp>

#include <functional>

//using namespace std;
using namespace pcl;
using namespace pcl::common;
using namespace pcl::io;
using namespace pcl::registration;
using namespace pcl::search;
using namespace pcl::visualization;
using namespace Eigen;


using namespace rw::common;
using namespace rw::graphics;
using namespace rw::kinematics;
using namespace rw::loaders;
using namespace rw::models;
using namespace rw::sensor;
using namespace rwlibs::opengl;
using namespace rwlibs::simulation;

//using namespace std;
using namespace rw::math;
using namespace rw::pathplanning;
using namespace rw::proximity;
using namespace rw::trajectory;
using namespace rwlibs::pathplanners;
using namespace rwlibs::proximitystrategies;


using namespace cv;

using namespace covis;

using namespace rws;


using namespace std::placeholders;
using namespace std;
//.................................................


//.....................................................

typedef PointNormal PointT;
typedef Histogram<153> FeatureT;
typedef rw::math::Transform3D<> Pose;

class SamplePlugin: public rws::RobWorkStudioPlugin, private Ui::SamplePlugin
{
Q_OBJECT
Q_INTERFACES( rws::RobWorkStudioPlugin )
Q_PLUGIN_METADATA(IID "dk.sdu.mip.Robwork.RobWorkStudioPlugin/0.1" FILE "plugin.json")
public:
    SamplePlugin();
    virtual ~SamplePlugin();

    virtual void open(rw::models::WorkCell* workcell);

    virtual void close();

    virtual void initialize();

private slots:
    void btnPressed();
    void timer();
    void getImage();
    void get25DImage();
  
    void stateChangedListener(const rw::kinematics::State& state);

    bool checkCollisions(Device::Ptr device, const State &state, const CollisionDetector &detector, const Q &q);
    void createPathRRTConnect(Q from, Q to,  double extend, double maxTime);
    Transform3D<> printProjectionMatrix(std::string frameName);
    void preprocessingPCL();
    void spatialFilterZ( pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr &output_cloud );
    void spatialFilterX( pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr &output_cloud );
    void spatialFilterY( pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr &output_cloud );
    Eigen::Matrix4f poseEstimationM2();
    void nearest_feature(const FeatureT& query, const PointCloud<FeatureT>& target, int &idx, float &distsq);
    float dist_sq(const FeatureT& query, const FeatureT& target);
    cv::Mat constructProjectionMat(Eigen::Matrix<double, 3, 4> KA, Eigen::Matrix<double, 4, 4> H);
    void getCamerasInfo(cv::Mat &proj_l, cv::Mat &proj_r, cv::Mat &cam_mat_l, cv::Mat &cam_mat_r);
    void getProjectionMatrix(const std::string &frameName, cv::Mat &output, cv::Mat &camMat);
    void runLinearInterpolation();
    void runRRT();
    //void linemod1();
    //void stereopsis();
    void linint();






    //int linemod1();
    //inline Rect autocrop(Mat& src);
    //inline bool isBorder(Mat& edge, Vec3b color);
/*
    cv::linemod::Detector createLinemodDetector( )
    {
        std::vector<char> pyramid;
        pyramid.push_back(4);
        pyramid.push_back(2);
        pyramid.push_back(1);
        //std::vector< Ptr<cv::linemod::Modality> > modals;
        std::vector<Ptr<cv::linemod::Modality>> m;
        //modals.push_back( cv::linemod::Modality::create ("ColorGradient") );
        cv::linemod::Detector detector(m, pyramid );
        return detector;
    }*/

private:
    static cv::Mat toOpenCVImage(const rw::sensor::Image& img);

    QTimer* _timer;
    QTimer* _timer25D;
    
    rw::models::WorkCell::Ptr _wc;
    rw::kinematics::State _state;
    rwlibs::opengl::RenderImage *_textureRender, *_bgRender;
    rwlibs::simulation::GLFrameGrabber* _framegrabber;
    rwlibs::simulation::GLFrameGrabber25D* _framegrabber25D;    
    std::vector<std::string> _cameras;
    std::vector<std::string> _cameras25D;
    Device::Ptr _device;
    QPath _path;
    unsigned int _step;
    unsigned int _stepGrasp;
    unsigned int _stepRelease;
    rw::kinematics::MovableFrame* _bottle;
    rw::kinematics::Frame* _table;
    rw::kinematics::Frame* _tcp;
    pcl::PointCloud<pcl::PointXYZ>::Ptr _scene;
    pcl::PointCloud<pcl::PointXYZ>::Ptr _object;
    rw::models::SerialDevice::Ptr _UR6;
    rw::kinematics::MovableFrame * _scanner25D;
    rw::kinematics::MovableFrame * _target;
    rw::math::Transform3D<> _place;
    rw::math::Q _home;
    rw::math::Transform3D<> _bottlePos;
    rw::math::Transform3D<> _bottleHomePos;
    rw::math::Transform3D<> _pose;

    //std::default_random_engine _generator;
    std::uniform_int_distribution<int> _xdist{-300,300};
    std::uniform_int_distribution<int> _ydist{350,550};
    std::uniform_int_distribution<int> _zrotdist{-3141, 3141};

};

#endif /*RINGONHOOKPLUGIN_HPP_*/
