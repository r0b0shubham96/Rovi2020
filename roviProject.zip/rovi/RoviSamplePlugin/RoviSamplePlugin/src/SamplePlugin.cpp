#include "SamplePlugin.hpp"
#include "rrt.hpp"
#include "interpolator.hpp"
//#include "methods.hpp"
#include <array>


SamplePlugin::SamplePlugin():
    RobWorkStudioPlugin("SamplePluginUI", QIcon("/home/student/Desktop/RoviSamplePlugin/src/pa_icon.png"))
{
	setupUi(this);

	_timer = new QTimer(this);
        connect(_timer, SIGNAL(timeout()), this, SLOT(timer()));

	// now connect stuff from the ui component
	connect(_btn_im    ,SIGNAL(pressed()), this, SLOT(btnPressed()) );
	connect(_btn_scan    ,SIGNAL(pressed()), this, SLOT(btnPressed()) );
	connect(_btn0    ,SIGNAL(pressed()), this, SLOT(btnPressed()) );
	connect(_btn1    ,SIGNAL(pressed()), this, SLOT(btnPressed()) );
	connect(_spinBox  ,SIGNAL(valueChanged(int)), this, SLOT(btnPressed()) );
    connect(_btnPCL   ,SIGNAL(pressed()), this, SLOT(btnPressed()) );
    connect(_btnM3   ,SIGNAL(pressed()), this, SLOT(btnPressed()) );
    connect(_com   ,SIGNAL(pressed()), this, SLOT(btnPressed()) );
    connect(_rrt   ,SIGNAL(pressed()), this, SLOT(btnPressed()) );

	_framegrabber = NULL;
	
	_cameras = {"Camera_Right", "Camera_Left"};
	_cameras25D = {"Scanner25D"};
}

SamplePlugin::~SamplePlugin()
{
    delete _textureRender;
    delete _bgRender;
}

void SamplePlugin::initialize()
{
    log().info() << "INITALIZE" << "\n";

    getRobWorkStudio()->stateChangedEvent().add(std::bind(&SamplePlugin::stateChangedListener, this, std::placeholders::_1), this);

    // Auto load workcell
    rw::models::WorkCell::Ptr wc = rw::loaders::WorkCellLoader::Factory::load("/home/student/Desktop/rovi/Project_WorkCell/Project_WorkCell/Scene.wc.xml");
    getRobWorkStudio()->setWorkCell(wc);

}

void SamplePlugin::open(rw::models::WorkCell* workcell)
{
    log().info() << "OPEN" << "\n";
    _wc = workcell;
    _state = _wc->getDefaultState();

    log().info() << workcell->getFilename() << "\n";
    if ( _wc == nullptr )
        RW_THROW("workcell not found.");
    if (_wc != NULL) {
    // Add the texture render to this workcell if there is a frame for texture
    rw::kinematics::Frame* textureFrame = _wc->findFrame("MarkerTexture");
    if (textureFrame != NULL) {
        getRobWorkStudio()->getWorkCellScene()->addRender("TextureImage",_textureRender,textureFrame);
    }
    // Add the background render to this workcell if there is a frame for texture
    rw::kinematics::Frame* bgFrame = _wc->findFrame("Background");
    if (bgFrame != NULL) {
        getRobWorkStudio()->getWorkCellScene()->addRender("BackgroundImage",_bgRender,bgFrame);
    }

    // Create a GLFrameGrabber if there is a camera frame with a Camera property set
    rw::kinematics::Frame* cameraFrame = _wc->findFrame(_cameras[0]);
    if (cameraFrame != NULL) {
        if (cameraFrame->getPropertyMap().has("Camera")) {
            // Read the dimensions and field of view
            double fovy;
            int width, height;
            std::string camParam = cameraFrame->getPropertyMap().get<std::string>("Camera");
            std::istringstream iss (camParam, std::istringstream::in);
            iss >> fovy >> width >> height;
            // Create a frame grabber
            _framegrabber = new rwlibs::simulation::GLFrameGrabber(width,height,fovy);
            rw::graphics::SceneViewer::Ptr gldrawer = getRobWorkStudio()->getView()->getSceneViewer();
            _framegrabber->init(gldrawer);
        }
    }

    rw::kinematics::Frame* cameraFrame25D = _wc->findFrame(_cameras25D[0]);
    if (cameraFrame25D != NULL) {
        if (cameraFrame25D->getPropertyMap().has("Scanner25D")) {
            // Read the dimensions and field of view
            double fovy;
            int width,height;
            std::string camParam = cameraFrame25D->getPropertyMap().get<std::string>("Scanner25D");
            std::istringstream iss (camParam, std::istringstream::in);
            iss >> fovy >> width >> height;
            // Create a frame grabber
            _framegrabber25D = new rwlibs::simulation::GLFrameGrabber25D(width,height,fovy);
            rw::graphics::SceneViewer::Ptr gldrawer = getRobWorkStudio()->getView()->getSceneViewer();
            _framegrabber25D->init(gldrawer);
        }
    }

    _bottle  = _wc->findFrame<rw::kinematics::MovableFrame>("Bottle");
    if ( _bottle == nullptr )
        RW_THROW("bottle frame not found.");

    _table = _wc->findFrame<rw::kinematics::Frame>("Table");
    if ( _table == nullptr )
        RW_THROW("Table frame not found.");

    _tcp   = _wc->findFrame<rw::kinematics::Frame>("UR-6-85-5-A.TCP");
    if ( _tcp == nullptr )
        RW_THROW("TCP frame not found.");

    _UR6 = _wc->findDevice<rw::models::SerialDevice>("UR-6-85-5-A");
    if ( _UR6 == nullptr )
        RW_THROW("Device UR6 not found.");

    _scanner25D = _wc->findFrame<rw::kinematics::MovableFrame>("Scanner25D");
    if ( _scanner25D == nullptr ){
        RW_THROW("Error finding frame: Scanner25D");
    }

    _target = _wc->findFrame<rw::kinematics::MovableFrame>("GraspTarget");
    if ( _target == nullptr )
        RW_THROW("Error finding frame: GraspTarget");


    _device = _wc->findDevice("UR-6-85-5-A");
    _step = -1;

    _home = _UR6->getQ(_state);
    _bottlePos = _bottle->getTransform(_state);
     cout << "BOTTLE POS:" << endl << _bottlePos << endl;
    _bottleHomePos = _bottlePos;
    }
}


void SamplePlugin::close() {
    log().info() << "CLOSE" << "\n";

    // Stop the timer
    _timer->stop();
    // Remove the texture render
    rw::kinematics::Frame* textureFrame = _wc->findFrame("MarkerTexture");
    if (textureFrame != NULL) {
        getRobWorkStudio()->getWorkCellScene()->removeDrawable("TextureImage",textureFrame);
    }
    // Remove the background render
    rw::kinematics::Frame* bgFrame = _wc->findFrame("Background");
    if (bgFrame != NULL) {
        getRobWorkStudio()->getWorkCellScene()->removeDrawable("BackgroundImage",bgFrame);
    }
    // Delete the old framegrabber
    if (_framegrabber != NULL) {
        delete _framegrabber;
    }
    _framegrabber = NULL;
    _wc = NULL;
}

cv::Mat SamplePlugin::toOpenCVImage(const rw::sensor::Image& img) {
    cv::Mat res(img.getHeight(),img.getWidth(), CV_8SC3);
    res.data = (uchar*)img.getImageData();
    return res;
}


void SamplePlugin::btnPressed() {
    QObject *obj = sender();
	if(obj==_btn0){
        log().info() << "Button 0\n";
    // Toggle the timer on and off
    if (!_timer25D->isActive())
        _timer25D->start(100); // run 10 Hz
    else
        _timer25D->stop();
        _timer->stop();
        rw::math::Math::seed();
        double extend = 0.05;
        double maxTime = 60;
        Q from(6, 1.571, -1.572, -1.572, -1.572, 1.571, 0);
        Q to(6,-1.002, -1.873, -1.698, -0.935, 1.571, 0); //From pose estimation Q[6]{-1.002, -1.873, -1.698, -0.935, 1.571, 0}
        createPathRRTConnect(from, to, extend, maxTime);


	} else if(obj==_btn1){
        log().info() << "Button 1\n";
        // Toggle the timer on and off
        if (!_timer->isActive()){
            _timer->start(100); // run 10 Hz
            _step = 0;
        }
        else
            _step = 0;

	} else if(obj==_spinBox){
		log().info() << "spin value:" << _spinBox->value() << "\n";
	}
	else if( obj==_btn_im ){
		getImage();
	}
	else if( obj==_btn_scan ){
		get25DImage();
    }else if(obj == _btnPCL){
        preprocessingPCL();
        poseEstimationM2();

    }else if(obj == _rrt){
        runRRT();
    }else if(obj == _com){
        linint();
    }else if(obj == _btnM3){
        //linemod1();
        //stereopsis();
    }
	

}


void SamplePlugin::get25DImage() {
	if (_framegrabber25D != NULL) {
		for( int i = 0; i < _cameras25D.size(); i ++)
		{
			// Get the image as a RW image
			Frame* cameraFrame25D = _wc->findFrame(_cameras25D[i]); // "Camera");
			_framegrabber25D->grab(cameraFrame25D, _state);

			//const Image& image = _framegrabber->getImage();

			const rw::geometry::PointCloud* img = &(_framegrabber25D->getImage());

            std::ofstream output("/home/student/Desktop/rovi/RoviSamplePlugin/RoviSamplePlugin/imgs/" + _cameras25D[i] + ".pcd");
			output << "# .PCD v.5 - Point Cloud Data file format\n";
			output << "FIELDS x y z\n";
			output << "SIZE 4 4 4\n";
			output << "TYPE F F F\n";
			output << "WIDTH " << img->getWidth() << "\n";
			output << "HEIGHT " << img->getHeight() << "\n";
			output << "POINTS " << img->getData().size() << "\n";
			output << "DATA ascii\n";
            for(const auto &p_tmp : img->getData())
			{
				rw::math::Vector3D<float> p = p_tmp;
				output << p(0) << " " << p(1) << " " << p(2) << "\n";
			}
			output.close();

		}
	}
}

void SamplePlugin::getImage() {
	if (_framegrabber != NULL) {
		for( int i = 0; i < _cameras.size(); i ++)
		{
			// Get the image as a RW image
			Frame* cameraFrame = _wc->findFrame(_cameras[i]); // "Camera");
			_framegrabber->grab(cameraFrame, _state);

			const rw::sensor::Image* rw_image = &(_framegrabber->getImage());

			// Convert to OpenCV matrix.
			cv::Mat image = cv::Mat(rw_image->getHeight(), rw_image->getWidth(), CV_8UC3, (rw::sensor::Image*)rw_image->getImageData());

			// Convert to OpenCV image
			Mat imflip, imflip_mat;
			cv::flip(image, imflip, 1);
			cv::cvtColor( imflip, imflip_mat, COLOR_RGB2BGR );

            cv::imwrite("/home/student/Desktop/rovi/RoviSamplePlugin/RoviSamplePlugin/imgs/"+ _cameras[i] + ".png", imflip_mat );

			// Show in QLabel
			QImage img(imflip.data, imflip.cols, imflip.rows, imflip.step, QImage::Format_RGB888);
			QPixmap p = QPixmap::fromImage(img);
			unsigned int maxW = 480;
			unsigned int maxH = 640;
			_label->setPixmap(p.scaled(maxW,maxH,Qt::KeepAspectRatio));
		}
	}
}

void SamplePlugin::timer() {


    if(0 <= _step && _step < _path.size()){
        _device->setQ(_path.at(_step),_state);
        getRobWorkStudio()->setState(_state);
        _step++;
    }
}

void SamplePlugin::stateChangedListener(const State& state) {
  _state = state;
}

bool SamplePlugin::checkCollisions(Device::Ptr device, const State &state, const CollisionDetector &detector, const Q &q) {
    State testState;
    CollisionDetector::QueryResult data;
    bool colFrom;

    testState = state;
    device->setQ(q,testState);
    colFrom = detector.inCollision(testState,&data);
    if (colFrom) {
        cerr << "Configuration in collision: " << q << endl;
        cerr << "Colliding frames: " << endl;
        FramePairSet fps = data.collidingFrames;
        for (FramePairSet::iterator it = fps.begin(); it != fps.end(); it++) {
            cerr << (*it).first->getName() << " " << (*it).second->getName() << endl;
        }
        return false;
    }
    return true;
}

void SamplePlugin::createPathRRTConnect(Q from, Q to,  double extend, double maxTime){
    _device->setQ(from,_state);
    getRobWorkStudio()->setState(_state);
    CollisionDetector detector(_wc, ProximityStrategyFactory::makeDefaultCollisionStrategy());
    PlannerConstraint constraint = PlannerConstraint::make(&detector,_device,_state);
    QSampler::Ptr sampler = QSampler::makeConstrained(QSampler::makeUniform(_device),constraint.getQConstraintPtr());
    QMetric::Ptr metric = MetricFactory::makeEuclidean<Q>();
    QToQPlanner::Ptr planner = RRTPlanner::makeQToQPlanner(constraint, sampler, metric, extend, RRTPlanner::RRTConnect);

    _path.clear();
    if (!checkCollisions(_device, _state, detector, from))
        cout << from << " is in colission!" << endl;
    if (!checkCollisions(_device, _state, detector, to))
        cout << to << " is in colission!" << endl;;
    Timer t;
    t.resetAndResume();
    planner->query(from,to,_path,maxTime);
    t.pause();


    if (t.getTime() >= maxTime) {
        cout << "Notice: max time of " << maxTime << " seconds reached." << endl;
    }

	const int duration = 10;

    if(_path.size() == 2){  //The interpolated path between Q start and Q goal is collision free. Set the duration with respect to the desired velocity
        LinearInterpolator<Q> linInt(from, to, duration);
        QPath tempQ;
        for(int i = 0; i < duration+1; i++){
            tempQ.push_back(linInt.x(i));
        }

        _path=tempQ;
    }
}
//************************************************R O B O T I C S _ P A R T*************************************************************************************

/*
void SamplePlugin::resetRobotAndObject()
{
    _bottlePos = _bottle->getTransform(_state);
    _device->setQ(_home,_state);
    _bottle->moveTo(_bottlePos, _state);
    getRobWorkStudio()->setState(_state);
}*/

void SamplePlugin::runRRT(){
    _bottlePos = _bottle->getTransform(_state);
    _device->setQ(_home,_state);
    _bottle->moveTo(_bottlePos, _state);
    getRobWorkStudio()->setState(_state);
     _target->moveTo(_bottlePos * _pose * rw::math::Transform3D<>(rw::math::RPY<>(0,0,rw::math::Pi).toRotation3D()) * rw::math::Transform3D<>(rw::math::RPY<>(rw::math::Pi/2,0,0).toRotation3D()), _state);
    getRobWorkStudio()->setState(_state);
    Eigen::Matrix4f bp = SamplePlugin::poseEstimationM2();
    rw::math::Rotation3D<> R = rw::math::Rotation3D<>(bp.data()[0],bp.data()[4],bp.data()[8], bp.data()[1], bp.data()[5], bp.data()[9], bp.data()[2],bp.data()[6],bp.data()[10] );
    rw::math::Vector3D<> V = rw::math::Vector3D<>(bp.data()[12],bp.data()[13],bp.data()[14]);
    _place = rw::math::Transform3D<>(V, R);
     _path = RRT::rrt_path_calculate(_place, _wc, _state, _device, _UR6, _tcp, _target, _stepGrasp, _stepRelease);
}




void SamplePlugin::linint()
{
    Eigen::Matrix4f bp = SamplePlugin::poseEstimationM2();
    rw::math::Rotation3D<> R = rw::math::Rotation3D<>(bp.data()[0],bp.data()[4],bp.data()[8], bp.data()[1], bp.data()[5], bp.data()[9], bp.data()[2],bp.data()[6],bp.data()[10] );
    rw::math::Vector3D<> V = rw::math::Vector3D<>(bp.data()[12],bp.data()[13],bp.data()[14]);
    _pose = rw::math::Transform3D<>(V, R);
    std::cout << "POSE: " << _pose << std::endl;
    _place = _table->getTransform(_state)*_bottle->getTransform(_state);
    _place.P()[0] = 0.318;
    _place.P()[1] = -0.470;
    std::cout << "POSE Place: " << _place << std::endl;
    //_place = _table->getTransform(_state)*_bottle->getTransform(_state);
  //  _target->moveTo(_scanner25D->getTransform(_state) * _pose * rw::math::Transform3D<>(rw::math::RPY<>(0,0,rw::math::Pi).toRotation3D()) * rw::math::Transform3D<>(rw::math::RPY<>(rw::math::Pi/2,0,0).toRotation3D()), _state);
    getRobWorkStudio()->setState(_state);

    runLinearInterpolation();

    if (!_timer->isActive()){
        _timer->start(10); // run 100 Hz
        _step = 0;
    }
    else
        _step = 0;

    //std::cout << "RRT place: " << _place << std::endl;
   // _path = RRT::rrt_path_calculate(_place, _wc, _state, _device, _UR6, _tcp, _target, _stepGrasp, _stepRelease);

}


void SamplePlugin::runLinearInterpolation(){
    _target->moveTo(_scanner25D->getTransform(_state) * _pose * rw::math::Transform3D<>(rw::math::RPY<>(0,0,rw::math::Pi).toRotation3D()) * rw::math::Transform3D<>(rw::math::RPY<>(rw::math::Pi/2,0,0).toRotation3D()), _state);
    cout << "Initializing linear interpolation to calculate path" << endl;

    /******/

    auto PointTimes = interpolator::util::getPointTimes(_target->getTransform(_state), _UR6->baseTend(_state), _place);
    std::vector<rw::math::Transform3D<>> Points = std::get<0>(PointTimes);
    std::vector<float> Times = std::get<1>(PointTimes);
    rw::proximity::CollisionDetector::Ptr detector = rw::common::ownedPtr(new rw::proximity::CollisionDetector(_wc, rwlibs::proximitystrategies::ProximityStrategyFactory::makeDefaultCollisionStrategy()));

    auto paths = interpolator::linearInterpolate(Points, Times, _target, _UR6, _wc, _state, detector);

    std::vector<rw::math::Q> jointPath = std::get<0>(paths);
    std::vector<rw::math::Transform3D<>> cartPath = std::get<1>(paths);

    for ( unsigned int i = 0; i < cartPath.size(); i++ )
    {
        if ( cartPath[i].P() == Points[2].P() )
            _stepGrasp = i;

        if ( cartPath[i].P() == Points[6].P() )
            _stepRelease = i;

    }
    std::cout << "Grasp step: " << _stepGrasp << std::endl;
    std::cout << "Release step: " << _stepRelease << std::endl;

    std::cout << "Path length: " << jointPath.size() << std::endl;

    _path.clear();
    for ( rw::math::Q configuration : jointPath ) // configurationPath
    {
        if ( configuration.size() == 6 )
            _path.push_back(configuration);
    }
    std::cout << "Collision free path length: " << _path.size() << std::endl;
}



//***************************************************************************************************************************************************************

cv::Mat SamplePlugin::constructProjectionMat(Eigen::Matrix<double, 3, 4> KA, Eigen::Matrix<double, 4, 4> H) {
    // convert eigen matrix to cv::mat
    cv::Mat _KA, _H;
    cv::eigen2cv(KA, _KA);
    cv::eigen2cv(H, _H);
    // construct projection matrix
    return _KA * _H;
}



void SamplePlugin::getCamerasInfo(cv::Mat &proj_l, cv::Mat &proj_r, cv::Mat &cam_mat_l, cv::Mat &cam_mat_r) {
    std::cout << "\nLeft camera.." << std::endl;
    getProjectionMatrix("Camera_Left", proj_l, cam_mat_l);
    std::cout << "\nLeft camera projection matrix -->\n" << proj_l << std::endl;
    std::cout << "\nLeft camera matrix -->\n" << cam_mat_l << std::endl;

    std::cout << "\nRight camera.." << std::endl;
    getProjectionMatrix("Camera_Right", proj_r, cam_mat_r);
    std::cout << "\nRight camera projection matrix -->\n" << proj_r << std::endl;
    std::cout << "\nRight camera matrix -->\n" << cam_mat_r << std::endl;
}



Transform3D<> SamplePlugin::printProjectionMatrix(std::string frameName) {



    Frame* cameraFrame = _wc->findFrame(frameName);
    if (cameraFrame != NULL) {
        if (cameraFrame->getPropertyMap().has("Camera")) {
            // Read the dimensions and field of view
            double fovy;
            int width,height;
            std::string camParam = cameraFrame->getPropertyMap().get<std::string>("Camera");
            std::istringstream iss (camParam, std::istringstream::in);
            iss >> fovy >> width >> height;

            double fovy_pixel = height / 2 / tan(fovy * (2*M_PI) / 360.0 / 2.0 );

            Eigen::Matrix<double, 3, 4> KA;
            KA << fovy_pixel, 0, width / 2.0, 0,
                  0, fovy_pixel, height / 2.0, 0,
                  0, 0, 1, 0;

            std::cout << "Ïntrinsic parameters:" << std::endl;
            std::cout << KA << std::endl;


            Transform3D<> camPosOGL = cameraFrame->wTf(_state);
            Transform3D<> openGLToVis = Transform3D<>(RPY<>(-Pi, 0, Pi).toRotation3D());
            Transform3D<> H = inverse(camPosOGL * inverse(openGLToVis));

            std::cout << "Extrinsic parameters:" << std::endl;
            std::cout << H.e() << std::endl;
            std::cout << "camPos:" << std::endl;
            std::cout << camPosOGL.e() << std::endl;
            std::cout << "OpenGLtoVis" << std::endl;
            std::cout << openGLToVis << std::endl;

            cv::Mat output = constructProjectionMat(KA, H.e());
            std::cout << "OUTPUTIS" << std::endl;
            std::cout << output << std::endl;


            return H;
            //return output;
        }
    }


}

void SamplePlugin::getProjectionMatrix(const std::string &frameName, cv::Mat &output, cv::Mat &camMat) {
    // load workcell
    //rw::models::WorkCell::Ptr wc = rw::loaders::WorkCellLoader::Factory::load(WC_FILE);

        State state = _wc->getDefaultState();
        Frame *cameraFrame = _wc->findFrame(frameName);
        if (cameraFrame != NULL) {
            if (cameraFrame->getPropertyMap().has("Camera")) {
                // Read the dimensions and field of view
                double fovy;
                int width, height;
                std::string camParam = cameraFrame->getPropertyMap().get<std::string>("Camera");
                std::istringstream iss(camParam, std::istringstream::in);
                iss >> fovy >> width >> height;

                double fovyPixel = height / 2 / tan(fovy * (2*M_PI) / 360.0 / 2.0);

                Eigen::Matrix<double, 3, 4> KA;
                KA << fovyPixel, 0, width /2.0, 0,
                      0, fovyPixel, height / 2.0, 0,
                      0, 0, 1, 0;

                // create camera matrix
                camMat = cv::Mat::zeros(3,3,CV_64FC1);
                camMat.at<double>(0,0) = fovyPixel;
                camMat.at<double>(1,1) = fovyPixel;
                camMat.at<double>(0,2) = width/2.0;
                camMat.at<double>(1,2) = height/2.0;
                camMat.at<double>(2,2) = 1;

                Pose camPosOGL = cameraFrame->wTf(state);
                Pose openGL2Vis = Pose(RPY<>(-Pi, 0, Pi).toRotation3D());
                Pose H = rw::math::inverse(camPosOGL * rw::math::inverse(openGL2Vis));

                output = constructProjectionMat(KA, H.e());
            }
        }

}

//*************************************************** VISION METHOD M2 *****************************************************************************
void SamplePlugin::preprocessingPCL(){
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud (new pcl::PointCloud<pcl::PointXYZ>);
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud_filtered (new pcl::PointCloud<pcl::PointXYZ>);

    // Fill in the cloud data
    pcl::PCDReader reader;
    reader.read ("/home/student/Desktop/rovi/RoviSamplePlugin/RoviSamplePlugin/imgs/Scanner25D.pcd", *cloud);

    pcl::PointXYZ minPt, maxPt;
    pcl::getMinMax3D (*cloud, minPt, maxPt);
    std::cout << "Max x: " << maxPt.x << std::endl;
    std::cout << "Max y: " << maxPt.y << std::endl;
    std::cout << "Max z: " << maxPt.z << std::endl;
    std::cout << "Min x: " << minPt.x << std::endl;
    std::cout << "Min y: " << minPt.y << std::endl;
    std::cout << "Min z: " << minPt.z << std::endl;

    std::cerr << "PointCloud before filtering: " << cloud->width * cloud->height
         << " data points (" << pcl::getFieldsList (*cloud) << ").";

    spatialFilterZ( cloud, cloud_filtered );
    spatialFilterY( cloud_filtered, cloud_filtered );
    spatialFilterX( cloud_filtered, cloud_filtered );

    std::cerr << "PointCloud after filtering: " << cloud_filtered->width * cloud_filtered->height
         << " data points (" << pcl::getFieldsList (*cloud_filtered) << ").";

    pcl::PCDWriter writer;
    writer.write<pcl::PointXYZ> ("/home/student/Desktop/rovi/RoviSamplePlugin/RoviSamplePlugin/imgs/cuttedScene.pcd", *cloud_filtered, false);
}

void SamplePlugin::spatialFilterZ( pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr &output_cloud )
{


    pcl::PassThrough<pcl::PointXYZ> pass;

    pass.setFilterFieldName ("z");
    pass.setFilterLimits (-1.5, -1.1);//-1.48 -1.23
    pass.setInputCloud (input_cloud);
    pass.filter (*output_cloud);

}
void SamplePlugin::spatialFilterY( pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr &output_cloud )
{

    pcl::PassThrough<pcl::PointXYZ> pass;
    pass.setFilterFieldName ("y");
    pass.setFilterLimits (-0.4, 0.3); // -0.3 0.105
    pass.setInputCloud (input_cloud);
    pass.filter (*output_cloud);

}
void SamplePlugin::spatialFilterX( pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud, pcl::PointCloud<pcl::PointXYZ>::Ptr &output_cloud )
{

    pcl::PassThrough<pcl::PointXYZ> pass;
    pass.setFilterFieldName ("x");
    pass.setFilterLimits (-6.2, 6.19); //-6.2 6.19
    pass.setInputCloud (input_cloud);
    pass.filter (*output_cloud);

}

Eigen::Matrix4f SamplePlugin::poseEstimationM2(){
    PointCloud<PointT>::Ptr object(new PointCloud<PointT>);
    PointCloud<PointT>::Ptr scene(new PointCloud<PointT>);
    loadPCDFile("/home/student/Desktop/rovi/RoviSamplePlugin/RoviSamplePlugin/imgs/bottlePCL.pcd", *object);
    loadPCDFile("/home/student/Desktop/rovi/RoviSamplePlugin/RoviSamplePlugin/imgs/cuttedScene.pcd", *scene);

    // Compute surface normals
    {
        ScopeTime t1("Surface normals");
        NormalEstimation<PointT,PointT> ne;
        ne.setKSearch(10); //Set the number of k nearest neighbors to use for the feature estimation.

        ne.setInputCloud(object);
        ne.compute(*object);

        ne.setInputCloud(scene);
        ne.compute(*scene);
    }

    // Compute shape features
    PointCloud<FeatureT>::Ptr object_features(new PointCloud<FeatureT>);
    PointCloud<FeatureT>::Ptr scene_features(new PointCloud<FeatureT>);
    {
        ScopeTime t1("Shape features");

        SpinImageEstimation<PointT,PointT,FeatureT> spin;

        /*Set the sphere radius that is to be used for determining the nearest neighbors used for the feature
        * estimation.
        * \param[in] radius the sphere radius used as the maximum distance to consider a point a neighbor*/
        spin.setRadiusSearch(0.05);//0.05

        spin.setInputCloud(object);
        spin.setInputNormals(object);
        spin.compute(*object_features);

        spin.setInputCloud(scene);
        spin.setInputNormals(scene);
        spin.compute(*scene_features);
    }

    // Find feature matches
    Correspondences corr(object_features->size());
    {
        ScopeTime t("Feature matches");
        for(size_t i = 0; i < object_features->size(); ++i) {
            corr[i].index_query = i;
            nearest_feature(object_features->points[i], *scene_features, corr[i].index_match, corr[i].distance);
        }
    }

    // Show matches
    {
        PCLVisualizer v("Matches");
        v.addPointCloud<PointT>(object, PointCloudColorHandlerCustom<PointT>(object, 0, 255, 0), "object");
        v.addPointCloud<PointT>(scene, PointCloudColorHandlerCustom<PointT>(scene, 255, 0, 0),"scene");
        v.addCorrespondences<PointT>(object, scene, corr, 1);
        v.spin();
    }

    // Create a k-d tree for scene
    search::KdTree<PointNormal> tree;
    tree.setInputCloud(scene);

    // Set RANSAC parameters
    const size_t iter1 = 4000; //3 >= 4 ? std::stoi(argv[3]) : 3000;
    const float thressq1 = 0.01 * 0.01;

    // Start RANSAC
    Matrix4f pose1 = Matrix4f::Identity();
    PointCloud<PointNormal>::Ptr object_aligned(new PointCloud<PointNormal>);
    float penalty = FLT_MAX;
    {
        ScopeTime t("RANSAC");
        cout << "Starting RANSAC..." << endl;
        UniformGenerator<int> gen(0, corr.size() - 1);
        for(size_t i = 0; i < iter1; ++i) {
            if((i + 1) % 100 == 0)
                cout << "\t" << i+1 << endl;
            // Sample 3 random correspondences
            vector<int> idxobj(3);
            vector<int> idxscn(3);
            for(int j = 0; j < 3; ++j) {
                const int idx = gen.run();
                idxobj[j] = corr[idx].index_query;
                idxscn[j] = corr[idx].index_match;
            }

            // Estimate transformation
            Matrix4f T;
            TransformationEstimationSVD<PointNormal,PointNormal> est;
            est.estimateRigidTransformation(*object, idxobj, *scene, idxscn, T);

            // Apply pose
            transformPointCloud(*object, *object_aligned, T);

            // Validate
            vector<vector<int> > idx;
            vector<vector<float> > distsq;
            tree.nearestKSearch(*object_aligned, std::vector<int>(), 1, idx, distsq);

            // Compute inliers and RMSE
            size_t inliers = 0;
            float rmse = 0;
            for(size_t j = 0; j < distsq.size(); ++j)
                if(distsq[j][0] <= thressq1)
                    ++inliers, rmse += distsq[j][0];
            rmse = sqrtf(rmse / inliers);

            // Evaluate a penalty function
            const float outlier_rate = 1.0f - float(inliers) / object->size();
            //const float penaltyi = rmse;
            const float penaltyi = outlier_rate;

            // Update result
            if(penaltyi < penalty) {
                cout << "\t--> Got a new model with " << inliers << " inliers!" << endl;
                penalty = penaltyi;
                pose1 = T;
            }
        }

        transformPointCloud(*object, *object_aligned, pose1);

        // Compute inliers and RMSE
        vector<vector<int> > idx;
        vector<vector<float> > distsq;
        tree.nearestKSearch(*object_aligned, std::vector<int>(), 1, idx, distsq);
        size_t inliers = 0;
        float rmse = 0;
        for(size_t i = 0; i < distsq.size(); ++i)
            if(distsq[i][0] <= thressq1)
                ++inliers, rmse += distsq[i][0];
        rmse = sqrtf(rmse / inliers);

        // Print pose
        cout << "Got the following pose:" << endl << pose1 << endl;
        cout << "Inliers: " << inliers << "/" << object->size() << endl;
        cout << "RMSE: " << rmse << endl;
    } // End timing


    // Show result
    {
        PCLVisualizer v("After global alignment");
        v.addPointCloud<PointT>(object_aligned, PointCloudColorHandlerCustom<PointT>(object_aligned, 0, 255, 0), "object_aligned");
        v.addPointCloud<PointT>(scene, PointCloudColorHandlerCustom<PointT>(scene, 255, 0, 0),"scene");
        v.spin();
        v.close();
    }

    //.......................................................................................................................................

    const size_t iter = 300; //argc >= 4 ? std::stoi(argv[3]) : 50;
    const float thressq = 0.01 * 0.01;

    // Start ICP
    Matrix4f pose2 = Matrix4f::Identity();


    {
        ScopeTime t("ICP");
        cout << "Starting ICP..." << endl;
        for(size_t i = 0; i < iter; ++i) {
            // 1) Find closest points
            vector<vector<int> > idx;
            vector<vector<float> > distsq;
            tree.nearestKSearch(*object_aligned, std::vector<int>(), 1, idx, distsq);

            // Threshold and create indices for object/scene and compute RMSE
            vector<int> idxobj;
            vector<int> idxscn;
            for(size_t j = 0; j < idx.size(); ++j) {
                if(distsq[j][0] <= thressq) {
                    idxobj.push_back(j);
                    idxscn.push_back(idx[j][0]);
                }
            }

            // 2) Estimate transformation
            Matrix4f T;
            TransformationEstimationSVD<PointNormal,PointNormal> est;
            est.estimateRigidTransformation(*object_aligned, idxobj, *scene, idxscn, T);

            // 3) Apply pose
            transformPointCloud(*object_aligned, *object_aligned, T);

            // 4) Update result
            pose2 = T * pose2;

        }
        cout << "pose: " << pose2 << endl;
        // Compute inliers and RMSE
        vector<vector<int> > idx;
        vector<vector<float> > distsq;
        tree.nearestKSearch(*object_aligned, std::vector<int>(), 1, idx, distsq);
        size_t inliers = 0;
        float rmse = 0;
        for(size_t i = 0; i < distsq.size(); ++i)
            if(distsq[i][0] <= thressq)
                ++inliers, rmse += distsq[i][0];
        rmse = sqrtf(rmse / inliers);

        // Print pose
        cout << "Got the following pose:" << endl << pose2 << endl;
        cout << "Inliers: " << inliers << "/" << object->size() << endl;
        cout << "RMSE: " << rmse << endl;
    } // End timing

    {
        PCLVisualizer v("After local alignment");
        v.addPointCloud<PointNormal>(object_aligned, PointCloudColorHandlerCustom<PointNormal>(object_aligned, 0, 255, 0), "object_aligned");
        v.addPointCloud<PointNormal>(scene, PointCloudColorHandlerCustom<PointNormal>(scene, 255, 0, 0),"scene");
        v.spin();


    }

    cv::waitKey();

    Matrix4f finalPose;
    finalPose = pose2 * pose1;
    cout << "Got the final pose:" << endl << finalPose << endl;
    //finalPose(0,3) = 0;
    //cout << "Got the final pose repaired:" << endl << finalPose << endl;

    Matrix4f finalPoseBottle, cTw;

    cTw(0,0) = 1;
    cTw(0,1) = 0;
    cTw(0,2) = 0;
    cTw(0,3) = 0;

    cTw(1,0) = 0;
    cTw(1,1) = 0.906308;
    cTw(1,2) = 0.422618;
    cTw(1,3) = 1.033;

    cTw(2,0) = 0;
    cTw(2,1) = -0.422618;
    cTw(2,2) = 0.906308;
    cTw(2,3) = 1.325;

    cTw(3,0) = 0;
    cTw(3,1) = 0;
    cTw(3,2) = 0;
    cTw(3,3) = 1;


    //cTw = (Matrix4f)printProjectionMatrix("Scanner25D").e();   //(Matrix4f)printProjectionMatrix("Scanner25D").;
    //Eigen::Matrix<double,4,4> test = printProjectionMatrix("Scanner25D").e();
    finalPoseBottle = cTw * finalPose;
    cout << "Got the final pose of bottle ref to world:" << endl << finalPoseBottle << endl;
    //_bottlePos = finalPoseBottle.
    return finalPoseBottle;
}

float SamplePlugin::dist_sq(const FeatureT& query, const FeatureT& target) {
    float result = 0.0;
    for(int i = 0; i < FeatureT::descriptorSize(); ++i) {
        const float diff = reinterpret_cast<const float*>(&query)[i] - reinterpret_cast<const float*>(&target)[i];
        result += diff * diff;
    }

    return result;
}

void SamplePlugin::nearest_feature(const FeatureT& query, const PointCloud<FeatureT>& target, int &idx, float &distsq) {
    idx = 0;
    distsq = dist_sq(query, target[0]);
    for(size_t i = 1; i < target.size(); ++i) {
        const float disti = dist_sq(query, target[i]);
        if(disti < distsq) {
            idx = i;
            distsq = disti;
        }
    }
}
//*************************************************** VISION METHOD M3 *****************************************************************************
/*
int SamplePlugin::linemod1() {


        const std::string ipath2 ="/home/student/Desktop/build-template_matching-Desktop-Default/Camera_Left.png";
        const std::string ipath ="/home/student/Desktop/build-template_matching-Desktop-Default/Camera_Right.png";

        const std::string tpath = "/home/student/Desktop/build-template_matching-Desktop-Default/";

        const float threshold = 50;


      // Training data to be loaded for the 2D matcher
      std::vector<Mat> templates;
      std::vector<Eigen::Matrix4f> tposes;

      std::vector<cv::Point> offset;

      int cnt = 0; // Current template index




      //cv::linemod::Detector detector = SamplePlugin::createLinemodDetector();




      while(true) {
        // Get RGB template
        char tfile[1024];
        sprintf(tfile, "/template%04i.png", cnt);
        Mat t = imread(tpath + std::string(tfile), IMREAD_UNCHANGED);
        std::cout << "cesta " << tpath << std::endl;
        if(t.empty())
          break;

        templates.push_back(t.clone());

        cv::Mat out;

        Rect win = autocrop(t);

        win.height = win.height + 4;
        win.width = win.width + 4;
        win.x = win.x - 2;
        win.y = win.y - 2;

        t = t(win);

        offset.push_back( cv::Point( win.width, win.height ));

        cv::inRange(t, cv::Scalar(0,0,244), cv::Scalar(1,1,255), out);
        out = 255 - out;

        //cv::imshow("template", t );
        //cv::imshow("mask", out );
        //cv::waitKey();

        std::vector<Mat> sources;
        sources.push_back(t.clone());

        sprintf(tfile, "%04i", cnt);

        // insert templates into the detectior
        detector.addTemplate ( sources, std::string(tfile), out );

        cnt++;
      }

      std::cout << "Number of templates: " << templates.size() << std::endl;




      for(int image_index = 0; image_index < int(ipath.size()); image_index++) {

        //Mat img = imread(ipath[image_index], IMREAD_UNCHANGED); // imread(po.getValue("image"), IMREAD_UNCHANGED);
        //COVIS_ASSERT_MSG(!img.empty(), "Cannot read test image " << po.getValue("image") << "!");

        Mat img = imread("/home/student/Desktop/build-template_matching-Desktop-Default/Camera_Right.png", IMREAD_UNCHANGED);
        cv::Mat image = img.clone();

        std::vector<Mat> sources;
        sources.push_back( image );

        std::vector< cv::linemod::Match > matches;

        detector.match( sources, threshold, matches );

        std::cout << "Number of matches: " << matches.size() << std::endl;

        int i = 0;

        cv::imshow("temp", templates[ atoi(matches[i].class_id.c_str()) ]);

        //circle(img, cv::Point( matches[i].x, matches[i].y), 8, cv::Scalar(0, 255, 0) , -1 );

        //drawMarker(CV_IN_OUT Mat& img, Point position, const Scalar& color,
                                     //int markerType = MARKER_CROSS, int markerSize=20, int thickness=1,
                                     //int line_type=8);

        drawMarker(img, cv::Point(matches[i].x + 20 , matches[i].y + 20),cv::Scalar(0,255,0),MARKER_CROSS,20,1,8);



        char pfile[1024];
        sprintf(pfile, "/template%04i_pose.txt",  atoi(matches[i].class_id.c_str()) );
        Eigen::Matrix4f m;
        covis::util::loadEigen(tpath + std::string(pfile), m);
        std::cout << "cesta2: " << tpath << std::endl;
        std::cout << m << std::endl;

        std::cout << "x: " << matches[i].x + 20 << std::endl;
        std::cout << "y: " << matches[i].y + 20 << std::endl;


        cv::imshow( "img", img );
        cv::waitKey(0);
        //return 0;
        break;
      }

      std::cout << "betweeeeeeeen " << std::endl;

      for(int image_index = 0; image_index < int(ipath2.size()); image_index++) {

        //Mat img = imread(ipath[image_index], IMREAD_UNCHANGED); // imread(po.getValue("image"), IMREAD_UNCHANGED);
        //COVIS_ASSERT_MSG(!img.empty(), "Cannot read test image " << po.getValue("image") << "!");

        Mat img = imread("/home/student/Desktop/build-template_matching-Desktop-Default/Camera_Left.png", IMREAD_UNCHANGED);
        cv::Mat image = img.clone();

        std::vector<Mat> sources;
        sources.push_back( image );

        std::vector< cv::linemod::Match > matches;

        detector.match( sources, threshold, matches );

        std::cout << "Number of matches: " << matches.size() << std::endl;

        int i = 0;

        cv::imshow("temp", templates[ atoi(matches[i].class_id.c_str()) ]);

        //circle(img, cv::Point( matches[i].x, matches[i].y), 8, cv::Scalar(0, 255, 0) , -1 );

        //drawMarker(CV_IN_OUT Mat& img, Point position, const Scalar& color,
                                     //int markerType = MARKER_CROSS, int markerSize=20, int thickness=1,
                                     //int line_type=8);

        drawMarker(img, cv::Point(matches[i].x + 20 , matches[i].y + 20),cv::Scalar(0,255,0),MARKER_CROSS,20,1,8);



        char pfile[1024];
        sprintf(pfile, "/template%04i_pose.txt",  atoi(matches[i].class_id.c_str()) );
        Eigen::Matrix4f m;
        covis::util::loadEigen(tpath + std::string(pfile), m);
        std::cout << "cesta2: " << tpath << std::endl;
        std::cout << m << std::endl;

        std::cout << "x: " << matches[i].x + 20 << std::endl;
        std::cout << "y: " << matches[i].y + 20 << std::endl;


        cv::imshow( "img", img );
        cv::waitKey(0);
        return 0;
      }
      return 0;
}



// Internal function used by autocrop()
inline bool SamplePlugin::isBorder(Mat& edge, Vec3b color) {
  Mat im = edge.clone().reshape(0,1);

  bool res = true;
  for(int i = 0; i < im.cols; ++i)
    res &= (color == im.at<Vec3b>(0,i));

  return res;
}

inline Rect SamplePlugin::autocrop(Mat& src) {
  COVIS_ASSERT(src.type()== CV_8UC3);
  Rect win(0, 0, src.cols, src.rows);

  vector<Rect> edges;
  edges.push_back(Rect(0, 0, src.cols, 1));
  edges.push_back(Rect(src.cols-2, 0, 1, src.rows));
  edges.push_back(Rect(0, src.rows-2, src.cols, 1));
  edges.push_back(Rect(0, 0, 1, src.rows));

  Mat edge;
  int nborder = 0;
  Vec3b color = src.at<Vec3b>(0,0);

  for (size_t i = 0; i < edges.size(); ++i) {
    edge = src(edges[i]);
    nborder += isBorder(edge, color);
  }

  if (nborder < 4)
    return win;

  bool next;

  do {
    edge = src(Rect(win.x, win.height-2, win.width, 1));
    if( (next = isBorder(edge, color)) )
      win.height--;
  } while (next && win.height > 0);

  do {
    edge = src(Rect(win.width-2, win.y, 1, win.height));
    if( (next = isBorder(edge, color)) )
      win.width--;
  } while (next && win.width > 0);

  do {
    edge = src(Rect(win.x, win.y, win.width, 1));
    if( (next = isBorder(edge, color)) )
      win.y++, win.height--;
  } while (next && win.y <= src.rows);

  do {
    edge = src(Rect(win.x, win.y, 1, win.height));
    if( (next = isBorder(edge, color)) )
      win.x++, win.width--;
  } while (next && win.x <= src.cols);

  return win;
}*/
/*
cv::Mat constructProjectionMat(Camera cam)
{
    cv::Mat KA = cam.intrinsic;
    cv::Mat H = cam.transformation;

    // Remember to add a row of zeros so the KA matrix becomes 3x4
    cv::Mat zeros = cv::Mat::zeros(3, 1, CV_64F);
    cv::hconcat(KA, zeros, KA);
    return KA * H;
}

std::array<cv::Mat, 2> splitPp(cv::Mat proj)
{
    std::array<cv::Mat, 2> Pp;
    Pp[0] = proj(cv::Range(0, 3), cv::Range(0, 3));
    Pp[1] = proj(cv::Range(0, 3), cv::Range(3, 4));
    return Pp;
}

cv::Mat computeOpticalCenter(std::array<cv::Mat, 2> Pp)
{
    // Compute in homogeneous coordiantes
    cv::Mat one = cv::Mat::ones(1, 1, CV_64F);
    cv::Mat C = -1.0 * Pp[0].inv(cv::DECOMP_SVD) * Pp[1];
    cv::vconcat(C, one, C);
    return C;
}

cv::Mat computeFundamentalMat(cv::Mat e, cv::Mat proj_r, cv::Mat proj_l)
{
    // Create symmetric skew 'cross product matrix' from the right epipole
    cv::Mat erx = cv::Mat::zeros(3, 3, CV_64F);
    erx.at<double>(0, 1) = -e.at<double>(2);
    erx.at<double>(0, 2) = e.at<double>(1);
    erx.at<double>(1, 0) = e.at<double>(2);
    erx.at<double>(1, 2) = -e.at<double>(0);
    erx.at<double>(2, 0) = -e.at<double>(1);
    erx.at<double>(2, 1) = e.at<double>(0);

    return erx * proj_r * proj_l.inv(cv::DECOMP_SVD);
}

void drawEpipolarLine(cv::Mat &img, cv::Mat line, double width)
{
    cv::Point p1, p2;
    double x = line.at<double>(0,0), y = line.at<double>(0,1), z = line.at<double>(0,2);
    p1.x = 0;
    p1.y = -z / y;
    p2.x = width;
    p2.y = -width * x / y - z / y;

    cv::line(img, p1, p2, cv::Scalar(0, 255, 0), 2, cv::LINE_AA);
}

std::array<cv::Mat, 2> computePluckerLine(cv::Mat M1, cv::Mat M2)
{
    std::array<cv::Mat, 2> plucker;
    plucker[0] = M1.cross(M2) / cv::norm(M2);
    plucker[1] = M2 / cv::norm(M2);
    return plucker;
}

cv::Mat computePluckerIntersect(std::array<cv::Mat, 2> plucker_1, std::array<cv::Mat, 2> plucker_2)
{
    cv::Mat mu1 = plucker_1[0], mu2 = plucker_2[0], v1 = plucker_1[1], v2 = plucker_2[1];

    // Compute the point on the left line which is closeset to the right line, and vica versa
    double v1_v2xmu2 = v1.dot(v2.cross(mu2));
    double v1v2_v1_v2xmu1 = v1.dot(v2) * v1.dot(v2.cross(mu1));
    double pow_v1xv2 = pow(norm(v1.cross(v2)), 2);
    cv::Mat M1 = (v1_v2xmu2 - v1v2_v1_v2xmu1) / pow_v1xv2 * v1 + v1.cross(mu1);

    double v2_v1xmu1 = v2.dot(v1.cross(mu1));
    double v2v1_v2_v1xmu2 = v2.dot(v1) * v2.dot(v1.cross(mu2));
    double pow_v2xv1 = pow(norm(v2.cross(v1)), 2);
    cv::Mat M2 = (v2_v1xmu1 - v2v1_v2_v1xmu2) / pow_v2xv1 * v2 + v2.cross(mu2);

    return M1 + (M2 - M1) / 2;
}

float distance(float x1, float y1,
            float z1, float x2,
            float y2, float z2)
{
    float d = sqrt(pow(x2 - x1, 2) +
                pow(y2 - y1, 2) +
                pow(z2 - z1, 2) * 1.0);
    std::cout << std::fixed;
    std::cout << std::setprecision(2);
    return d;
}

void SamplePlugin::stereopsis()
{

    cv::Mat img_l, img_r;
    StereoPair stereoPair;
     img_l = cv::imread("/home/student/Desktop/rovi/RoviSamplePlugin/RoviSamplePlugin/imgs/Camera_Left.png");
     img_r = cv::imread("/home/student/Desktop/rovi/RoviSamplePlugin/RoviSamplePlugin/imgs/Camera_Right.png");


    auto proj_l = constructProjectionMat(stereoPair.cam1);
    auto proj_r = constructProjectionMat(stereoPair.cam2);


    proj_l.at<double>(0,0) = -532.5949537729517;
    proj_l.at<double>(0,1) = -165.2310730611422;
    proj_l.at<double>(0,2) = -237.3573672763966;
    proj_l.at<double>(0,3) = 353.6923593827499;

    proj_l.at<double>(1,0) = 20.77877201007961;
    proj_l.at<double>(1,1) = 219.8164471865489;
    proj_l.at<double>(1,2) = -523.2075919458428;
    proj_l.at<double>(1,3) = 17.72782686670962;

    proj_l.at<double>(2,0) = -0.06311708837492605;
    proj_l.at<double>(2,1) = -0.6677090502078462;
    proj_l.at<double>(2,2) = -0.7417417727387393;
    proj_l.at<double>(2,3) = 1.111662550435493;

    proj_r.at<double>(0,0) = -492.2000172129991;
    proj_r.at<double>(0,1) = -262.1027190718794;
    proj_r.at<double>(0,2) = -237.3573672763966;
    proj_r.at<double>(0,3) = 357.7716728959658;

    proj_r.at<double>(1,0) = -20.77877201007973;
    proj_r.at<double>(1,1) = 219.8164471865489;
    proj_r.at<double>(1,2) = -523.2075919458428;
    proj_r.at<double>(1,3) = 17.72782686670962;

    proj_r.at<double>(2,0) = 0.06311708837492605;
    proj_r.at<double>(2,1) = -0.6677090502078462;
    proj_r.at<double>(2,2) = -0.7417417727387393;
    proj_r.at<double>(2,3) = 1.111662550435493;

    std::cout << "Camera 1 (left) projection matrix" << std::endl << proj_l << std::endl << std::endl;
    std::cout << "Camera 2 (right) projection matrix" << std::endl << proj_r << std::endl << std::endl;

    auto Pp_l = splitPp(proj_l);
    auto Pp_r = splitPp(proj_r);
    auto C_l = computeOpticalCenter(Pp_l);
    auto C_r = computeOpticalCenter(Pp_r);
    std::cout << "Optical centerLeft: " << std::endl << C_l << std::endl << std::endl;
    std::cout << "Optical centerRight" << std::endl << C_r << std::endl << std::endl;

    cv::Mat e_l = proj_l * C_r;
    cv::Mat e_r = proj_r * C_l;
    std::cout << "Left epipole: " << std::endl << e_l << std::endl << std::endl;
    std::cout << "Right epipole:" << std::endl << e_r << std::endl << std::endl;

    auto F_lr = computeFundamentalMat(e_r, proj_r, proj_l);
    std::cout << "Fundamental matrix left to right:" << std::endl << F_lr << std::endl << std::endl;

    // Detect mouseclick in left image
    auto m_l = getMouseClick("LeftImage", img_l);

    cv::Mat e_line_r = F_lr * m_l;
    std::cout << "Right epipolar line:" << std::endl << e_line_r << std::endl << std::endl;

    drawEpipolarLine(img_r, e_line_r, stereoPair.cam2.image_width);

    // Detect mouseclick in right image
    auto m_r = getMouseClick("Right image", img_r);


    //Matches from linemod algorithm
    //matches[0].x
   // matches[1].x
    //matches[0].y
    //matches[1].y

    //m_l.at<double>(0, 0) = matches[0].x;
    // m_l.at<double>(1, 0) = matches[0].y;
    //m_r.at<double>(0, 0) = matches[1].x;
    //m_r.at<double>(1, 0) = matches[1].y;


    // // Project points to infinity
    auto M_inf_l = Pp_l[0].inv(cv::DECOMP_SVD) * m_l;
    auto M_inf_r = Pp_r[0].inv(cv::DECOMP_SVD) * m_r;

    auto plucker_l = computePluckerLine(C_l(cv::Range(0, 3), cv::Range(0, 1)), M_inf_l);
    auto plucker_r = computePluckerLine(C_r(cv::Range(0, 3), cv::Range(0, 1)), M_inf_r);
    std::cout << "Plucker line parameters:" << std::endl;
    std::cout << "mu_l: " << plucker_l[0] << std::endl
              << "v_l: " << plucker_l[1] << std::endl << std::endl;
    std::cout << "mu_r: " << plucker_r[0] << std::endl
              << "v_r: " << plucker_r[1] << std::endl << std::endl;

    auto intersection = computePluckerIntersect(plucker_l, plucker_r);
    std::cout << "Triangulated point:" << std::endl << intersection << std::endl;
    std::cout << "-------------------" << std::endl << std::endl;

    // Compare with OpenCV triangulation
    cv::Mat pnts3D(1, 1, CV_64FC4);
    cv::Mat cam0pnts(1, 1, CV_64FC2);
    cv::Mat cam1pnts(1, 1, CV_64FC2);
    cam0pnts.at<cv::Vec2d>(0)[0] = m_l.at<double>(0, 0);
    cam0pnts.at<cv::Vec2d>(0)[1] = m_l.at<double>(1, 0);
    cam1pnts.at<cv::Vec2d>(0)[0] = m_r.at<double>(0, 0);
    cam1pnts.at<cv::Vec2d>(0)[1] = m_r.at<double>(1, 0);
    triangulatePoints(proj_l, proj_r, cam0pnts, cam1pnts, pnts3D);
    std::cout << "OpenCV triangulation" << std::endl;
    std::cout << "Image points: " << cam0pnts << "\t" << cam1pnts << std::endl << std::endl;
    pnts3D.at<double>(1, 0) = pnts3D.at<double>(1, 0) - 0.043;
    std::cout << "Triangulated point (normalized): " << std::endl << pnts3D / pnts3D.at<double>(3, 0) << std::endl << std::endl;
    cv::Mat h = pnts3D / pnts3D.at<double>(3, 0);

    float res = distance(-0.15, 0.473, 0.11,pnts3D.at<double>(0, 0),pnts3D.at<double>(1, 0),pnts3D.at<double>(2, 0));
    std::cout << "Euc dist: " << res << std::endl;
    std::cout << "Euc dist: " << h << std::endl;
    std::cout << "Done" << std::endl;
    cv::destroyAllWindows();
}

*/
